self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "567ef3a3f5e35442c539",
    "url": "/static/js/main.37fd972f.chunk.js"
  },
  {
    "revision": "07bd55e3309cc34a3d4f",
    "url": "/static/js/2.d213048e.chunk.js"
  },
  {
    "revision": "567ef3a3f5e35442c539",
    "url": "/static/css/main.237811d5.chunk.css"
  },
  {
    "revision": "827091fe1a90353dd1f4ee8f5739bbbf",
    "url": "/index.html"
  }
];